<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>日程を選ぶ</title>
</head>
<body>
    <h1 id="logo">TripPlanner</h1>

    <h2>日程を選ぶ</h2>
    <a href="index.html">戻る</a>

    <p>
        出発日
        <input type="date" name="departure" id="departure">

        帰着日
        <input type="date" name="return" id="return">

        <br>
        <a href="location.html">次へ</a>
    </p>

    <p>
        <a href="index.html">トップへ戻る</a>
    </p>
</body>
</html>