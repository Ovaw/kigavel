<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>プランの提案</title>
</head>
<body>
    <h1 id="logo">TripPlanner</h1>

    <h2>このようなプランはいかがですか</h2>
    <a href="location.html">戻る</a>

    <p>
        ああああ
    </p>

    <p>
        <a href="index.html">トップへ戻る</a> 
    </p>
</body>
</html>